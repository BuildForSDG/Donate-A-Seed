const app = async () => '#BuildforSDG';

export default app;
